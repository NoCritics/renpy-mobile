label start:
    "Hello."
    return
