# a REAL game file in a directory called lib
